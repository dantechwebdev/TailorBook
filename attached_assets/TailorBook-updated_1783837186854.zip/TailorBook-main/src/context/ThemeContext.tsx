import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { Appearance } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  ColorPalette,
  ThemeMode,
  darkColors,
  lightColors,
} from '../constants/theme';

// ─── Types ─────────────────────────────────────────────────────────────────────

/** User-facing preference. 'system' follows the OS appearance setting. */
export type ThemePreference = ThemeMode | 'system';

interface ThemeContextValue {
  /** Resolved theme actually being rendered ('light' | 'dark'). */
  mode: ThemeMode;
  /** Raw user preference, including 'system'. */
  preference: ThemePreference;
  /** Active color palette for the resolved mode. */
  colors: ColorPalette;
  isDark: boolean;
  /** Whether the persisted preference has finished loading from disk. */
  isReady: boolean;
  setPreference: (preference: ThemePreference) => void;
  /** Convenience toggle between explicit 'light' and 'dark' (leaves 'system'). */
  toggleTheme: () => void;
}

const STORAGE_KEY = 'tailorbook:theme-preference';

const resolveMode = (preference: ThemePreference): ThemeMode => {
  if (preference === 'system') {
    return Appearance.getColorScheme() === 'dark' ? 'dark' : 'light';
  }
  return preference;
};

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

// ─── Provider ──────────────────────────────────────────────────────────────────

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [preference, setPreferenceState] = useState<ThemePreference>('system');
  const [systemScheme, setSystemScheme] = useState(Appearance.getColorScheme());
  const [isReady, setIsReady] = useState(false);

  // Load persisted preference once on mount.
  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (isMounted && (stored === 'light' || stored === 'dark' || stored === 'system')) {
          setPreferenceState(stored);
        }
      } catch (e) {
        console.warn('ThemeContext: failed to load theme preference', e);
      } finally {
        if (isMounted) setIsReady(true);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, []);

  // Track OS appearance changes for 'system' preference.
  useEffect(() => {
    const sub = Appearance.addChangeListener(({ colorScheme }) => {
      setSystemScheme(colorScheme);
    });
    return () => sub.remove();
  }, []);

  const setPreference = useCallback((next: ThemePreference) => {
    setPreferenceState(next);
    AsyncStorage.setItem(STORAGE_KEY, next).catch((e) =>
      console.warn('ThemeContext: failed to persist theme preference', e)
    );
  }, []);

  const toggleTheme = useCallback(() => {
    setPreferenceState((current) => {
      const currentMode = current === 'system' ? resolveMode('system') : current;
      const next: ThemePreference = currentMode === 'dark' ? 'light' : 'dark';
      AsyncStorage.setItem(STORAGE_KEY, next).catch((e) =>
        console.warn('ThemeContext: failed to persist theme preference', e)
      );
      return next;
    });
  }, []);

  const mode: ThemeMode =
    preference === 'system' ? (systemScheme === 'dark' ? 'dark' : 'light') : preference;

  const value = useMemo<ThemeContextValue>(
    () => ({
      mode,
      preference,
      colors: mode === 'dark' ? darkColors : lightColors,
      isDark: mode === 'dark',
      isReady,
      setPreference,
      toggleTheme,
    }),
    [mode, preference, isReady, setPreference, toggleTheme]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

// ─── Hook ──────────────────────────────────────────────────────────────────────

export const useTheme = (): ThemeContextValue => {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error('useTheme() must be used within a <ThemeProvider>');
  }
  return ctx;
};
