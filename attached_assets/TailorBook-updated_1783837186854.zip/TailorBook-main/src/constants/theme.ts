// ─── TailorBook Design Tokens ─────────────────────────────────────────────────
// Warm, practical, modern — feels like a premium notebook, not a dashboard.
//
// Color palettes are split into `lightColors` and `darkColors` so the app can
// support Light Mode and Dark Mode from a single source of truth. Screens and
// components should consume colors via `useTheme()` (see `src/context/ThemeContext.tsx`)
// rather than importing `Colors` directly, so they react to the active theme.
// `Colors` is kept as an alias for `lightColors` for backwards compatibility.

export type ThemeMode = 'light' | 'dark';

export interface ColorPalette {
  primary: string;
  primaryLight: string;
  primaryDark: string;
  primaryFaint: string;

  accent: string;
  accentLight: string;

  overdue: string;
  overdueLight: string;
  dueSoon: string;
  dueSoonLight: string;
  ready: string;
  readyLight: string;
  cutting: string;
  cuttingLight: string;
  sewing: string;
  sewingLight: string;
  finishing: string;
  finishingLight: string;
  delivered: string;
  deliveredLight: string;
  pending: string;
  pendingLight: string;

  white: string;
  background: string;
  surface: string;
  surfaceElevated: string;
  border: string;
  borderLight: string;
  divider: string;

  textPrimary: string;
  textSecondary: string;
  textTertiary: string;
  textInverse: string;
  textLink: string;

  drawerBg: string;
  drawerActive: string;
  drawerText: string;
  drawerTextMuted: string;

  // Brand — the TailorBook logo's signature blue. Stays constant across themes
  // so the brand mark and splash screen never look "off" in dark mode.
  brand: string;
}

export const lightColors: ColorPalette = {
  // Primary — deep indigo-purple, confident and premium
  primary: '#4B3FA0',
  primaryLight: '#6558B8',
  primaryDark: '#362D7A',
  primaryFaint: '#F0EEFF',

  // Accent — warm amber for highlights and CTAs
  accent: '#F5A623',
  accentLight: '#FFF3DC',

  // Semantic Status Colors
  overdue: '#E8443A',
  overdueLight: '#FFF0EF',
  dueSoon: '#F5A623',
  dueSoonLight: '#FFF8EC',
  ready: '#34A853',
  readyLight: '#EBF8EF',
  cutting: '#1A73E8',
  cuttingLight: '#E8F2FF',
  sewing: '#9C27B0',
  sewingLight: '#F5E9FF',
  finishing: '#FF7043',
  finishingLight: '#FFF1EE',
  delivered: '#78909C',
  deliveredLight: '#F2F5F6',
  pending: '#F5A623',
  pendingLight: '#FFF8EC',

  // Neutrals
  white: '#FFFFFF',
  background: '#F7F8FC',
  surface: '#FFFFFF',
  surfaceElevated: '#FFFFFF',
  border: '#EAEEF4',
  borderLight: '#F2F5F8',
  divider: '#EAEEF4',

  // Text
  textPrimary: '#1A1A2E',
  textSecondary: '#6B7280',
  textTertiary: '#9CA3AF',
  textInverse: '#FFFFFF',
  textLink: '#4B3FA0',

  // Drawer / Dark Surface (the drawer is intentionally dark in both themes)
  drawerBg: '#1C1642',
  drawerActive: '#2D2468',
  drawerText: '#FFFFFF',
  drawerTextMuted: '#A5A3C2',

  brand: '#3470A2',
};

export const darkColors: ColorPalette = {
  // Primary — brightened slightly so it stays legible on dark surfaces
  primary: '#8B7FE8',
  primaryLight: '#A79EF0',
  primaryDark: '#6558B8',
  primaryFaint: '#241F45',

  accent: '#F5B84D',
  accentLight: '#3A2E14',

  overdue: '#FF6B61',
  overdueLight: '#3A1E1C',
  dueSoon: '#F5B84D',
  dueSoonLight: '#3A2E14',
  ready: '#4FCB7C',
  readyLight: '#173323',
  cutting: '#5B9CF6',
  cuttingLight: '#152A42',
  sewing: '#C67AE0',
  sewingLight: '#2E1D38',
  finishing: '#FF8F6B',
  finishingLight: '#3A2018',
  delivered: '#93A5AD',
  deliveredLight: '#20272A',
  pending: '#F5B84D',
  pendingLight: '#3A2E14',

  // Neutrals
  white: '#FFFFFF',
  background: '#111119',
  surface: '#1A1A26',
  surfaceElevated: '#22222F',
  border: '#2C2C3A',
  borderLight: '#25252F',
  divider: '#2C2C3A',

  // Text
  textPrimary: '#F2F2F7',
  textSecondary: '#A7A7B8',
  textTertiary: '#71717F',
  textInverse: '#1A1A2E',
  textLink: '#A79EF0',

  // Drawer stays the same near-black indigo across both themes
  drawerBg: '#150F35',
  drawerActive: '#2D2468',
  drawerText: '#FFFFFF',
  drawerTextMuted: '#A5A3C2',

  brand: '#3470A2',
};

/** @deprecated Prefer `useTheme().colors` so components respond to Dark Mode. */
export const Colors = lightColors;

export const Typography = {
  // Font sizes
  xs: 11,
  sm: 13,
  base: 15,
  md: 16,
  lg: 18,
  xl: 22,
  xxl: 26,
  display: 32,

  // Font weights (React Native uses string values)
  regular: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
  extrabold: '800' as const,

  // Line heights
  tight: 1.2,
  normal: 1.5,
  relaxed: 1.7,
} as const;

export const Spacing = {
  xxs: 2,
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 48,
} as const;

export const Radius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
  full: 9999,
} as const;

export const Shadow = {
  sm: {
    shadowColor: '#1A1A2E',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  md: {
    shadowColor: '#1A1A2E',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
  },
  lg: {
    shadowColor: '#1A1A2E',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 16,
    elevation: 8,
  },
} as const;

// ─── Job Status Config ─────────────────────────────────────────────────────────
// Built from a ColorPalette so it can be recomputed per-theme. `JOB_STATUS_CONFIG`
// (light theme) is kept for any call sites that haven't migrated to `useTheme()` yet.

export const getJobStatusConfig = (colors: ColorPalette) => ({
  Pending: {
    color: colors.pending,
    bgColor: colors.pendingLight,
    label: 'Pending',
  },
  Cutting: {
    color: colors.cutting,
    bgColor: colors.cuttingLight,
    label: 'Cutting',
  },
  Sewing: {
    color: colors.sewing,
    bgColor: colors.sewingLight,
    label: 'Sewing',
  },
  Finishing: {
    color: colors.finishing,
    bgColor: colors.finishingLight,
    label: 'Finishing',
  },
  Ready: {
    color: colors.ready,
    bgColor: colors.readyLight,
    label: 'Ready',
  },
  Delivered: {
    color: colors.delivered,
    bgColor: colors.deliveredLight,
    label: 'Delivered',
  },
});

/** @deprecated Prefer `getJobStatusConfig(useTheme().colors)`. */
export const JOB_STATUS_CONFIG = getJobStatusConfig(lightColors);

export const OUTFIT_TYPES = [
  'Agbada',
  'Senator',
  'Suit',
  'Shirt',
  'Trouser',
  'Gown',
  'Kaftan',
  'Skirt',
  'Blouse',
  'Other',
] as const;

export const JOB_STATUSES = [
  'Pending',
  'Cutting',
  'Sewing',
  'Finishing',
  'Ready',
  'Delivered',
] as const;

// ─── Measurement Templates ─────────────────────────────────────────────────────

export const MEASUREMENT_FIELDS = {
  mens_senator: [
    { key: 'chest', label: 'Chest', unit: '"' },
    { key: 'shoulder', label: 'Shoulder', unit: '"' },
    { key: 'sleeveLength', label: 'Sleeve Length', unit: '"' },
    { key: 'topLength', label: 'Top Length', unit: '"' },
    { key: 'trouserWaist', label: 'Trouser Waist', unit: '"' },
    { key: 'hip', label: 'Hip', unit: '"' },
    { key: 'trouserLength', label: 'Trouser Length', unit: '"' },
    { key: 'thigh', label: 'Thigh', unit: '"' },
    { key: 'knee', label: 'Knee', unit: '"' },
    { key: 'ankle', label: 'Ankle', unit: '"' },
  ],
  agbada: [
    { key: 'chest', label: 'Chest', unit: '"' },
    { key: 'shoulder', label: 'Shoulder', unit: '"' },
    { key: 'agbadaLength', label: 'Agbada Length', unit: '"' },
    { key: 'agbadaSleeve', label: 'Agbada Sleeve', unit: '"' },
    { key: 'innerwearLength', label: 'Inner Wear Length', unit: '"' },
    { key: 'trouserWaist', label: 'Trouser Waist', unit: '"' },
    { key: 'hip', label: 'Hip', unit: '"' },
    { key: 'trouserLength', label: 'Trouser Length', unit: '"' },
    { key: 'thigh', label: 'Thigh', unit: '"' },
    { key: 'ankle', label: 'Ankle', unit: '"' },
  ],
  suit: [
    { key: 'chest', label: 'Chest', unit: '"' },
    { key: 'shoulder', label: 'Shoulder', unit: '"' },
    { key: 'sleeveLength', label: 'Sleeve Length', unit: '"' },
    { key: 'jacketLength', label: 'Jacket Length', unit: '"' },
    { key: 'trouserWaist', label: 'Trouser Waist', unit: '"' },
    { key: 'hip', label: 'Hip', unit: '"' },
    { key: 'trouserLength', label: 'Trouser Length', unit: '"' },
    { key: 'thigh', label: 'Thigh', unit: '"' },
    { key: 'knee', label: 'Knee', unit: '"' },
  ],
  womens_gown: [
    { key: 'bust', label: 'Bust', unit: '"' },
    { key: 'waist', label: 'Waist', unit: '"' },
    { key: 'hip', label: 'Hip', unit: '"' },
    { key: 'shoulderWidth', label: 'Shoulder Width', unit: '"' },
    { key: 'sleeveLength', label: 'Sleeve Length', unit: '"' },
    { key: 'gownLength', label: 'Gown Length', unit: '"' },
    { key: 'neckSize', label: 'Neck Size', unit: '"' },
    { key: 'armhole', label: 'Arm Hole', unit: '"' },
  ],
  shirt: [
    { key: 'chest', label: 'Chest', unit: '"' },
    { key: 'shoulder', label: 'Shoulder', unit: '"' },
    { key: 'sleeveLength', label: 'Sleeve Length', unit: '"' },
    { key: 'shirtLength', label: 'Shirt Length', unit: '"' },
    { key: 'collar', label: 'Collar', unit: '"' },
  ],
  trouser: [
    { key: 'trouserWaist', label: 'Waist', unit: '"' },
    { key: 'hip', label: 'Hip', unit: '"' },
    { key: 'trouserLength', label: 'Length', unit: '"' },
    { key: 'thigh', label: 'Thigh', unit: '"' },
    { key: 'knee', label: 'Knee', unit: '"' },
    { key: 'ankle', label: 'Ankle', unit: '"' },
  ],
  custom: [],
};

export const TEMPLATE_LABELS: Record<string, string> = {
  mens_senator: "Men's Senator",
  agbada: 'Agbada',
  suit: 'Suit',
  womens_gown: "Women's Gown",
  shirt: 'Shirt',
  trouser: 'Trouser',
  custom: 'Custom',
};

// ─── Avatar Colors ─────────────────────────────────────────────────────────────

export const AVATAR_COLORS = [
  '#4B3FA0',
  '#E8443A',
  '#34A853',
  '#F5A623',
  '#1A73E8',
  '#9C27B0',
  '#FF7043',
  '#00897B',
  '#546E7A',
  '#8D6E63',
];
