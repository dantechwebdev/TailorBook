// ─── Customer Types ───────────────────────────────────────────────────────────

export interface Customer {
  id: string;
  name: string;
  phone: string;
  whatsappPhone?: string;
  notes?: string;
  avatar?: string;
  createdAt: string;
  updatedAt: string;
}

// ─── Measurement Types ────────────────────────────────────────────────────────

export type MeasurementTemplate =
  | 'mens_senator'
  | 'agbada'
  | 'suit'
  | 'womens_gown'
  | 'shirt'
  | 'trouser'
  | 'custom';

export interface Measurements {
  id: string;
  customerId: string;
  template: MeasurementTemplate;
  data: Record<string, string>;
  createdAt: string;
  updatedAt: string;
  label?: string;
}

// ─── Job Types ────────────────────────────────────────────────────────────────

export type OutfitType =
  | 'Agbada'
  | 'Senator'
  | 'Suit'
  | 'Shirt'
  | 'Trouser'
  | 'Gown'
  | 'Kaftan'
  | 'Skirt'
  | 'Blouse'
  | 'Other';

export type JobStatus =
  | 'Pending'
  | 'Cutting'
  | 'Sewing'
  | 'Finishing'
  | 'Ready'
  | 'Delivered';

export type DeliveryType = 'pickup' | 'waybill';

export interface Job {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  outfitType: string;
  style?: string;
  fabric?: string;
  deliveryDate: string;
  deliveryType: DeliveryType;
  deliveryAddress?: string;
  price: number;
  deposit: number;
  balance: number;
  status: JobStatus;
  measurementId?: string;
  photoUris?: string[];
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// ─── Notification Types ───────────────────────────────────────────────────────

export type NotificationType =
  | 'overdue'
  | 'due_today'
  | 'due_soon'
  | 'completed'
  | 'payment'
  | 'system';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  jobId?: string;
  customerId?: string;
  read: boolean;
  createdAt: string;
}

// ─── Settings Types ───────────────────────────────────────────────────────────

export interface TailorSettings {
  tailorName: string;
  shopName: string;
  phone: string;
  location: string;
  currency: string;
  workDays: string;       // JSON array e.g. '["Mon","Tue","Wed","Thu","Fri","Sat"]'
  defaultApparel: string; // e.g. 'Senator'
  onboardingComplete: string; // '0' or '1'
  profilePhotoUri?: string; // optional tailor/storefront photo URI
}

// ─── Today Task (derived from jobs for Home screen) ────────────────────────

export type TaskType =
  | 'pickup_today'
  | 'waybill_today'
  | 'overdue'
  | 'balance_due'
  | 'ready_notify'
  | 'in_progress';

export interface TodayTask {
  id: string;
  type: TaskType;
  label: string;
  subLabel?: string;
  job: Job;
}

// ─── Job Reminder Types ───────────────────────────────────────────────────────

/**
 * A single reminder configured for a job. This is the ONE model that backs every
 * reminder in the app — there is no separate "automatic" vs "custom" system.
 * When a job is created, TailorBook seeds a couple of sensible default reminders
 * (see `getDefaultReminderPresets` in `utils/notifications`) as ordinary rows here;
 * the user can add more, remove any of them, or change the presets in Settings.
 */
export interface JobReminder {
  id: string;
  jobId: string;
  scheduledAt: string;       // ISO datetime of the (next) fire time
  label: string;

  /**
   * Minutes before the job's delivery date/time this reminder fires, for
   * "relative" reminders (e.g. 180 = 3 hours before). `undefined` means the
   * reminder is pinned to an absolute date (`scheduledAt`) instead, and won't
   * move if the delivery date changes.
   */
  minutesBeforeDelivery?: number;

  /** @deprecated Superseded by `minutesBeforeDelivery` (kept for reminders created before this field existed). */
  daysBefore?: number;

  /** @deprecated Legacy finite-repeat field from the old "repeat every N days" UI. Superseded by `isRecurringOverdue`. */
  repeatEvery?: number;

  /**
   * When true, this isn't a single notification but a standing "remind me every
   * day this job is overdue" reminder. It's automatically cancelled the moment
   * the job's status becomes `Ready` or `Delivered`. See `notifications/reminderEngine.ts`.
   */
  isRecurringOverdue?: boolean;

  /**
   * expo-notifications identifier(s) for cancellation. For a normal reminder this
   * is a single scheduled notification's identifier. For a recurring-overdue
   * reminder it's the *prefix* shared by every underlying scheduled instance
   * (they're looked up and cancelled by prefix, not stored individually).
   */
  notifIdentifier?: string;

  createdAt: string;
}

/** A selectable "remind me X before delivery" preset shown in the reminder picker. */
export interface ReminderPreset {
  key: string;
  label: string;
  minutesBefore: number;
}

// ─── Scratch Note Types ───────────────────────────────────────────────────────

export interface ScratchNote {
  id: string;
  text: string;
  reminderAt?: string;       // ISO datetime — when to fire the push notification
  notifIdentifier?: string;  // expo-notifications identifier for cancellation
  isDone: boolean;
  createdAt: string;
  updatedAt: string;
}

// ─── Navigation Types ─────────────────────────────────────────────────────────

export type DrawerParamList = {
  HomeTab: undefined;
  CustomersStack: undefined;
  JobsStack: undefined;
  NotificationsScreen: undefined;
  AccountScreen: undefined;
  SubscriptionScreen: undefined;
  HelpScreen: undefined;
};

export type HomeStackParamList = {
  Home: undefined;
};

export type CustomerStackParamList = {
  CustomerList: undefined;
  CustomerDetail: { customerId: string };
  CustomerCreate: undefined;
  CustomerEdit: { customerId: string };
};

export type JobStackParamList = {
  JobList: undefined;
  JobDetail: { jobId: string };
  NewOrderFlow: { customerId?: string; step?: number };
  JobEdit: { jobId: string };
  CustomerDetail: { customerId: string };
  MeasurementForm: {
    customerId: string;
    jobId?: string;
    template?: MeasurementTemplate;
    existingMeasurementId?: string;
  };
};
