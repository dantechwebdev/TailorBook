// ─── Notifications Module (native) ────────────────────────────────────────────
// Public surface used by the rest of the app. Internals are split by concern:
//   scheduler.ts         → low-level expo-notifications primitives (permissions,
//                           channel, correctly-typed scheduling, cancellation)
//   presets.ts            → reminder preset definitions + pure date math
//   reminderEngine.ts     → job reminder orchestration (schedule/cancel/
//                           reschedule/recurring-overdue/boot reconciliation)
//   scratchReminders.ts   → one-shot scratch note reminders

export { requestNotificationPermissions, addNotificationResponseListener } from './scheduler';

export {
  REMINDER_PRESETS,
  DEFAULT_REMINDER_HOUR,
  getDefaultReminderMinutes,
  scheduleJobReminder,
  cancelJobReminder,
  rescheduleJobReminder,
  startOrExtendRecurringOverdue,
  stopRecurringOverdue,
  reconcileReminders,
} from './reminderEngine';

export { scheduleScratchReminder, cancelScratchReminder } from './scratchReminders';
