import { parseISO } from 'date-fns';
import { Job, JobReminder } from '../../types';
import { scheduleAt, cancel, cancelByPrefix } from './scheduler';
import {
  ALL_PRESETS,
  DEFAULT_REMINDER_HOUR,
  OVERDUE_REMINDER_HOUR,
  RECURRING_OVERDUE_WINDOW_DAYS,
  computeReminderDate,
} from './presets';

// ─── Job Reminder Engine ───────────────────────────────────────────────────────
// This is the single place that knows how a `JobReminder` record turns into an
// actual scheduled OS notification. `store.ts` owns persistence (the `job_reminders`
// table is the source of truth for *what reminders exist*); this module owns
// translating that intent into `expo-notifications` calls and keeping the two in
// sync (initial scheduling, cancellation, rescheduling on edits, and recurring
// overdue nudges).

const reminderIdentifier = (jobId: string, reminderId: string) => `job:${jobId}:reminder:${reminderId}`;
const overduePrefix = (jobId: string) => `job:${jobId}:overdue:`;

function jobReminderContent(job: Job, label: string) {
  return {
    title: `Reminder: ${job.outfitType}`,
    body: label ? `${job.customerName}'s ${job.outfitType} — ${label}` : `${job.customerName}'s ${job.outfitType}`,
    data: { jobId: job.id, type: 'job_reminder' },
  };
}

// ─── Defaults (seeded automatically when a job is created) ────────────────────

/** Sensible default reminders every new job gets: 1 day before, and on delivery day. */
export function getDefaultReminderMinutes(): number[] {
  return [24 * 60, 0]; // 1 day before, on delivery day
}

// ─── Preset / Custom Reminders ─────────────────────────────────────────────────

export interface ScheduleReminderInput {
  reminderId: string;
  job: Job;
  label: string;
  /** Relative reminder — recalculated automatically if the job's delivery date changes. */
  minutesBeforeDelivery?: number;
  /** Absolute reminder — fixed regardless of delivery date changes. */
  specificDate?: Date;
}

export interface ScheduleReminderResult {
  scheduledAt: Date;
  identifier: string | null;
}

/** Schedules (or re-schedules) a single job reminder and returns when it will fire. */
export async function scheduleJobReminder(input: ScheduleReminderInput): Promise<ScheduleReminderResult> {
  const { reminderId, job, label, minutesBeforeDelivery, specificDate } = input;
  const identifier = reminderIdentifier(job.id, reminderId);

  const scheduledAt =
    specificDate ?? computeReminderDate(parseISO(job.deliveryDate), minutesBeforeDelivery ?? 0);

  const result = await scheduleAt(identifier, jobReminderContent(job, label), scheduledAt);
  return { scheduledAt, identifier: result };
}

/** Cancel a single reminder's underlying scheduled notification. */
export async function cancelJobReminder(reminder: JobReminder): Promise<void> {
  if (reminder.isRecurringOverdue) {
    await cancelByPrefix(overduePrefix(reminder.jobId));
    return;
  }
  await cancel(reminderIdentifier(reminder.jobId, reminder.id));
}

/**
 * Re-point a "relative" reminder at a job's (possibly changed) delivery date.
 * No-ops for absolute (specific-date) reminders, which intentionally don't move.
 */
export async function rescheduleJobReminder(
  reminder: JobReminder,
  job: Job
): Promise<ScheduleReminderResult | null> {
  if (reminder.minutesBeforeDelivery === undefined) return null; // absolute reminder — leave it alone
  await cancel(reminderIdentifier(job.id, reminder.id));
  return scheduleJobReminder({
    reminderId: reminder.id,
    job,
    label: reminder.label,
    minutesBeforeDelivery: reminder.minutesBeforeDelivery,
  });
}

// ─── Recurring "Still Overdue" Reminders ───────────────────────────────────────
//
// expo-notifications has no "repeat every 24h, starting on date X, until
// cancelled" primitive on Android — its native `DAILY` trigger always starts
// from the *next* occurrence of the given time, which would fire before the job
// is even overdue. Instead we schedule a bounded run of individual daily
// instances (`RECURRING_OVERDUE_WINDOW_DAYS` of them) and extend the window every
// time the app is opened (see `reconcileReminders` below) for as long as the job
// stays un-resolved. This is a deliberate, documented trade-off of any purely
// local (non-push) notification system — see the audit summary for details.

/** (Re)schedules the overdue-reminder window for a job. Safe to call repeatedly. */
export async function startOrExtendRecurringOverdue(job: Job): Promise<void> {
  const prefix = overduePrefix(job.id);
  await cancelByPrefix(prefix); // idempotent: clear any stale instances, then lay down a fresh window

  const deliveryDate = parseISO(job.deliveryDate);
  const now = new Date();
  const firstOverdueDay = new Date(Math.max(deliveryDate.getTime(), now.getTime()));
  firstOverdueDay.setDate(firstOverdueDay.getDate() + 1); // starts the day *after* delivery/today
  firstOverdueDay.setHours(OVERDUE_REMINDER_HOUR, 0, 0, 0);

  const dayOffsets = Array.from({ length: RECURRING_OVERDUE_WINDOW_DAYS }, (_, i) => i);
  await Promise.all(
    dayOffsets.map((dayOffset) => {
      const date = new Date(firstOverdueDay);
      date.setDate(date.getDate() + dayOffset);
      return scheduleAt(
        `${prefix}${dayOffset}`,
        {
          title: '⏰ Still overdue',
          body: `${job.customerName}'s ${job.outfitType} is still overdue. Update its status once it's done.`,
          data: { jobId: job.id, type: 'overdue' },
        },
        date
      );
    })
  );
}

export async function stopRecurringOverdue(jobId: string): Promise<void> {
  await cancelByPrefix(overduePrefix(jobId));
}

// ─── Boot-Time Reconciliation ───────────────────────────────────────────────────
//
// Guarantees reminders are actually scheduled with the OS even if: the DB and
// OS state ever drifted apart, the app was reinstalled and DB restored from a
// backup, or (for recurring-overdue reminders) the pre-scheduled window is
// running low and needs extending. Scheduling is idempotent (deterministic
// identifiers + cancel-before-create), so calling this on every app launch is
// cheap and safe.

export async function reconcileReminders(jobs: Job[], reminders: JobReminder[]): Promise<void> {
  const jobsById = new Map(jobs.map((j) => [j.id, j]));

  await Promise.all(
    reminders.map(async (reminder) => {
      const job = jobsById.get(reminder.jobId);
      if (!job || reminder.isRecurringOverdue) return; // recurring ones are handled below
      const scheduledAt = new Date(reminder.scheduledAt);
      if (scheduledAt.getTime() <= Date.now()) return; // already in the past — nothing to do
      await scheduleAt(
        reminderIdentifier(job.id, reminder.id),
        jobReminderContent(job, reminder.label),
        scheduledAt
      );
    })
  );

  const activeRecurringJobIds = new Set(
    reminders.filter((r) => r.isRecurringOverdue).map((r) => r.jobId)
  );
  await Promise.all(
    Array.from(activeRecurringJobIds).map(async (jobId) => {
      const job = jobsById.get(jobId);
      if (job && job.status !== 'Ready' && job.status !== 'Delivered') {
        await startOrExtendRecurringOverdue(job);
      }
    })
  );
}

export { ALL_PRESETS as REMINDER_PRESETS, DEFAULT_REMINDER_HOUR };
