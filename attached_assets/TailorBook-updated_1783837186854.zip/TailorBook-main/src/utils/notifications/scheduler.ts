import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

// ─── Notification Handler ──────────────────────────────────────────────────────
// Must be set at module load (before any screen renders) so foreground
// notifications are actually presented instead of silently swallowed.

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

// ─── Android Notification Channel ─────────────────────────────────────────────

export const JOB_REMINDERS_CHANNEL_ID = 'job-reminders';

let channelReady: Promise<void> | null = null;

/** Idempotent — safe to call as often as needed (it only does work once per process). */
export function ensureAndroidChannel(): Promise<void> {
  if (Platform.OS !== 'android') return Promise.resolve();
  if (!channelReady) {
    channelReady = Notifications.setNotificationChannelAsync(JOB_REMINDERS_CHANNEL_ID, {
      name: 'Job Reminders',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#3470A2',
      description: 'Reminders about upcoming and overdue jobs',
    }).then(() => undefined);
  }
  return channelReady;
}

// ─── Permissions ───────────────────────────────────────────────────────────────

export async function requestNotificationPermissions(): Promise<boolean> {
  await ensureAndroidChannel();

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  if (existingStatus === 'granted') return true;

  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

// ─── Core Scheduling Primitive ─────────────────────────────────────────────────
//
// THE ROOT-CAUSE FIX:
// expo-notifications (SDK 50+ / ~0.28) requires every trigger to carry an explicit
// `type` discriminant (`SchedulableTriggerInputTypes.DATE`, `.DAILY`, etc). The
// previous implementation passed `{ date, channelId }` with no `type`, which
// isn't a valid `DateTriggerInput` — the calls only "compiled" because two of the
// three call sites force-cast the object with `as any`, hiding the type error
// instead of fixing it. At runtime this shape is not reliably recognized as a
// one-shot date trigger, especially in production (non-Expo-Go) Android builds,
// so `scheduleNotificationAsync` would resolve successfully (no thrown error,
// giving the appearance of success) without the OS ever actually registering an
// alarm/work request for it. Every scheduling call in this module now goes
// through this one function, which builds a correctly-typed trigger.

export async function scheduleAt(
  identifier: string,
  content: { title: string; body: string; data?: Record<string, unknown> },
  date: Date
): Promise<string | null> {
  const hasPermission = await requestNotificationPermissions();
  if (!hasPermission) return null;
  if (date.getTime() <= Date.now()) return null;

  try {
    await Notifications.scheduleNotificationAsync({
      identifier,
      content: {
        title: content.title,
        body: content.body,
        data: content.data ?? {},
        sound: 'default',
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date,
        channelId: JOB_REMINDERS_CHANNEL_ID,
      },
    });
    return identifier;
  } catch (e) {
    console.warn(`notifications: failed to schedule "${identifier}"`, e);
    return null;
  }
}

export async function cancel(identifier: string): Promise<void> {
  try {
    await Notifications.cancelScheduledNotificationAsync(identifier);
  } catch {
    // Already cancelled/fired — nothing to do.
  }
}

/** Cancel every currently-scheduled notification whose identifier starts with `prefix`. */
export async function cancelByPrefix(prefix: string): Promise<void> {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  const matches = scheduled.filter((n) => n.identifier.startsWith(prefix));
  await Promise.all(matches.map((n) => cancel(n.identifier)));
}

export async function getAllScheduled(): Promise<Notifications.NotificationRequest[]> {
  return Notifications.getAllScheduledNotificationsAsync();
}

// ─── Tap Handling ──────────────────────────────────────────────────────────────

export function addNotificationResponseListener(
  handler: (jobId: string) => void
): Notifications.Subscription {
  return Notifications.addNotificationResponseReceivedListener((response) => {
    const jobId = response.notification.request.content.data?.jobId;
    if (jobId) handler(jobId as string);
  });
}
