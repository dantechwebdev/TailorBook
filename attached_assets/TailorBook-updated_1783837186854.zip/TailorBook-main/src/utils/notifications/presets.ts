import { ReminderPreset } from '../../types';

// ─── Reminder Presets ──────────────────────────────────────────────────────────
// Single source of truth for the "remind me ___ before delivery" options shown
// in the UI (JobDetailScreen's reminder picker). Adding a preset here is enough
// to make it selectable — no other file needs to change.

export const REMINDER_PRESETS: ReminderPreset[] = [
  { key: '30m', label: '30 minutes before', minutesBefore: 30 },
  { key: '1h', label: '1 hour before', minutesBefore: 60 },
  { key: '3h', label: '3 hours before', minutesBefore: 3 * 60 },
  { key: '6h', label: '6 hours before', minutesBefore: 6 * 60 },
  { key: '12h', label: '12 hours before', minutesBefore: 12 * 60 },
  { key: '1d', label: '1 day before', minutesBefore: 24 * 60 },
  { key: '2d', label: '2 days before', minutesBefore: 2 * 24 * 60 },
  { key: '3d', label: '3 days before', minutesBefore: 3 * 24 * 60 },
  { key: '1w', label: '1 week before', minutesBefore: 7 * 24 * 60 },
];

/** The reminders a job gets automatically the moment it's created. */
export const DEFAULT_REMINDER_PRESET_KEYS = ['1d', '0'] as const;

// A "due today" reminder isn't naturally expressible as "minutes before" a
// specific time, so it's modelled separately as 0 minutes-before delivery, fired
// at the DEFAULT_REMINDER_HOUR on the delivery date itself.
export const DUE_TODAY_PRESET: ReminderPreset = {
  key: '0',
  label: 'On delivery day',
  minutesBefore: 0,
};

export const ALL_PRESETS: ReminderPreset[] = [DUE_TODAY_PRESET, ...REMINDER_PRESETS];

/** Local hour (24h) that day-granularity reminders fire at, absent a specific time. */
export const DEFAULT_REMINDER_HOUR = 8;

/** Local hour recurring "still overdue" nudges fire at each day. */
export const OVERDUE_REMINDER_HOUR = 9;

/**
 * How many daily instances to pre-schedule at once for a recurring-overdue
 * reminder. expo-notifications has no "repeat daily forever, starting on date X"
 * primitive — a `DAILY` trigger starts from the *next* occurrence of the given
 * time, which is wrong here (it would start firing before the job is even due).
 * Instead we schedule a bounded window of individual daily instances and extend
 * the window on every app launch via `reconcileReminders()`, which gives
 * effectively-indefinite recurrence as long as the shop owner opens the app at
 * least this often. See notifications/reminderEngine.ts for details.
 */
export const RECURRING_OVERDUE_WINDOW_DAYS = 14;

/**
 * Compute the fire time for a "minutes before delivery" reminder.
 * Day-granularity presets (>= 1 day) are pinned to `DEFAULT_REMINDER_HOUR` local
 * time, matching how the reminder is described in the UI ("1 day before, at 8:00
 * AM") rather than an exact-to-the-minute offset from delivery time. Sub-day
 * presets (30m/1h/3h/6h/12h) are computed as an exact offset instead, since
 * "3 hours before" only makes sense as an exact interval.
 */
export function computeReminderDate(deliveryDate: Date, minutesBefore: number): Date {
  if (minutesBefore === 0) {
    const d = new Date(deliveryDate);
    d.setHours(DEFAULT_REMINDER_HOUR, 0, 0, 0);
    return d;
  }
  if (minutesBefore >= 24 * 60) {
    const d = new Date(deliveryDate.getTime() - minutesBefore * 60 * 1000);
    d.setHours(DEFAULT_REMINDER_HOUR, 0, 0, 0);
    return d;
  }
  return new Date(deliveryDate.getTime() - minutesBefore * 60 * 1000);
}
