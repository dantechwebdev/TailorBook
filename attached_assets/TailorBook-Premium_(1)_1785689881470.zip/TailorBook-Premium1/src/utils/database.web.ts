import { Customer, Job, Measurements, AppNotification, TailorSettings, JobReminder, ScratchNote, JobImage, StudioConcept } from '../types';

const STORAGE_KEY = 'tailorbook_db';

interface DB {
  customers: Customer[];
  jobs: Job[];
  measurements: Measurements[];
  notifications: AppNotification[];
  settings: Record<string, string>;
  jobReminders: JobReminder[];
  scratchNotes: ScratchNote[];
  jobImages: JobImage[];
  studioConcepts: StudioConcept[];
}

function load(): DB {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { settings: {}, jobReminders: [], scratchNotes: [], jobImages: [], studioConcepts: [], ...JSON.parse(raw) };
  } catch {}
  return { customers: [], jobs: [], measurements: [], notifications: [], settings: {}, jobReminders: [], scratchNotes: [], jobImages: [], studioConcepts: [] };
}

function save(db: DB): void {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); } catch {}
}

export async function getDatabase(): Promise<any> { return {}; }

// ─── Settings ─────────────────────────────────────────────────────────────────

const DEFAULT_SETTINGS: TailorSettings = {
  tailorName: '', shopName: '', phone: '', location: '', currency: '₦',
  workDays: '["Mon","Tue","Wed","Thu","Fri","Sat"]',
  defaultApparel: '',
  onboardingComplete: '0',
  profilePhotoUri: '',
};

export async function getSettings(): Promise<TailorSettings> {
  const db = load();
  const s = db.settings || {};
  return {
    tailorName: s['tailorName'] ?? DEFAULT_SETTINGS.tailorName,
    shopName: s['shopName'] ?? DEFAULT_SETTINGS.shopName,
    phone: s['phone'] ?? DEFAULT_SETTINGS.phone,
    location: s['location'] ?? DEFAULT_SETTINGS.location,
    currency: s['currency'] ?? DEFAULT_SETTINGS.currency,
    workDays: s['workDays'] ?? DEFAULT_SETTINGS.workDays,
    defaultApparel: s['defaultApparel'] ?? DEFAULT_SETTINGS.defaultApparel,
    onboardingComplete: s['onboardingComplete'] ?? DEFAULT_SETTINGS.onboardingComplete,
    profilePhotoUri: s['profilePhotoUri'] ?? '',
  };
}

export async function saveSettings(settings: TailorSettings): Promise<void> {
  const db = load();
  db.settings = { ...db.settings, ...settings } as any;
  save(db);
}

// ─── Customers ────────────────────────────────────────────────────────────────

export async function getAllCustomers(): Promise<Customer[]> {
  return load().customers.sort((a, b) => a.name.localeCompare(b.name));
}

export async function getCustomerById(id: string): Promise<Customer | null> {
  return load().customers.find((c) => c.id === id) || null;
}

export async function createCustomer(customer: Customer): Promise<void> {
  const db = load(); db.customers.push(customer); save(db);
}

export async function updateCustomer(customer: Customer): Promise<void> {
  const db = load();
  db.customers = db.customers.map((c) => (c.id === customer.id ? customer : c));
  save(db);
}

export async function deleteCustomer(id: string): Promise<void> {
  const db = load();
  db.customers = db.customers.filter((c) => c.id !== id);
  db.jobs = db.jobs.filter((j) => j.customerId !== id);
  db.measurements = db.measurements.filter((m) => m.customerId !== id);
  save(db);
}

export async function searchCustomers(query: string): Promise<Customer[]> {
  const q = query.toLowerCase();
  return load().customers.filter(
    (c) => c.name.toLowerCase().includes(q) || c.phone.includes(q)
  );
}

// ─── Jobs ─────────────────────────────────────────────────────────────────────

export async function getAllJobs(): Promise<Job[]> {
  return load().jobs.sort((a, b) => a.deliveryDate.localeCompare(b.deliveryDate));
}

export async function getJobsByCustomer(customerId: string): Promise<Job[]> {
  return load().jobs.filter((j) => j.customerId === customerId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getJobById(id: string): Promise<Job | null> {
  return load().jobs.find((j) => j.id === id) || null;
}

export async function createJob(job: Job): Promise<void> {
  const db = load(); db.jobs.push(job); save(db);
}

export async function updateJob(job: Job): Promise<void> {
  const db = load();
  db.jobs = db.jobs.map((j) => (j.id === job.id ? job : j));
  save(db);
}

export async function updateJobStatus(id: string, status: string, updatedAt: string): Promise<void> {
  const db = load();
  db.jobs = db.jobs.map((j) => (j.id === id ? { ...j, status: status as any, updatedAt } : j));
  save(db);
}

export async function deleteJob(id: string): Promise<void> {
  const db = load();
  db.jobs = db.jobs.filter((j) => j.id !== id);
  save(db);
}

function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export async function getJobsDueToday(): Promise<Job[]> {
  const today = todayStr();
  return load().jobs.filter(
    (j) => j.deliveryDate.split('T')[0] === today && j.status !== 'Delivered'
  );
}

export async function getOverdueJobs(): Promise<Job[]> {
  const today = todayStr();
  return load().jobs.filter(
    (j) => j.deliveryDate.split('T')[0] < today && j.status !== 'Delivered' && j.status !== 'Ready'
  );
}

export async function getPendingJobs(): Promise<Job[]> {
  const today = todayStr();
  return load().jobs.filter(
    (j) => j.status !== 'Delivered' && j.deliveryDate.split('T')[0] >= today
  );
}

export async function getReadyJobs(): Promise<Job[]> {
  return load().jobs.filter((j) => j.status === 'Ready');
}

export async function getRecentJobs(limit = 10): Promise<Job[]> {
  return load().jobs.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit);
}

export async function getPendingWaybills(): Promise<Job[]> {
  return load().jobs.filter((j) => j.deliveryType === 'waybill' && j.status === 'Ready')
    .sort((a, b) => a.deliveryDate.localeCompare(b.deliveryDate));
}

export async function getOutstandingBalances(): Promise<Job[]> {
  return load().jobs.filter((j) => j.status === 'Delivered' && j.balance > 0)
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function searchJobs(query: string): Promise<Job[]> {
  const q = query.toLowerCase();
  return load().jobs.filter(
    (j) =>
      j.customerName.toLowerCase().includes(q) ||
      j.outfitType.toLowerCase().includes(q) ||
      j.status.toLowerCase().includes(q)
  );
}

// ─── Measurements ─────────────────────────────────────────────────────────────

export async function getMeasurementsByCustomer(customerId: string): Promise<Measurements[]> {
  return load().measurements.filter((m) => m.customerId === customerId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getMeasurementById(id: string): Promise<Measurements | null> {
  return load().measurements.find((m) => m.id === id) || null;
}

export async function createMeasurement(measurement: Measurements): Promise<void> {
  const db = load(); db.measurements.push(measurement); save(db);
}

export async function updateMeasurement(measurement: Measurements): Promise<void> {
  const db = load();
  db.measurements = db.measurements.map((m) => (m.id === measurement.id ? measurement : m));
  save(db);
}

// ─── Notifications ────────────────────────────────────────────────────────────

export async function getAllNotifications(): Promise<AppNotification[]> {
  return load().notifications.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 100);
}

export async function getUnreadNotificationCount(): Promise<number> {
  return load().notifications.filter((n) => !n.read).length;
}

export async function createNotification(notification: AppNotification): Promise<void> {
  const db = load(); db.notifications.unshift(notification); save(db);
}

export async function markNotificationRead(id: string): Promise<void> {
  const db = load();
  db.notifications = db.notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
  save(db);
}

export async function markAllNotificationsRead(): Promise<void> {
  const db = load();
  db.notifications = db.notifications.map((n) => ({ ...n, read: true }));
  save(db);
}

export async function deleteNotificationsByJobId(jobId: string): Promise<void> {
  const db = load();
  db.notifications = db.notifications.filter((n) => n.jobId !== jobId || n.type === 'system');
  save(db);
}

// ─── Job Reminders ────────────────────────────────────────────────────────────

export async function getAllJobReminders(): Promise<JobReminder[]> {
  return load().jobReminders.sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt));
}

export async function getJobRemindersByJob(jobId: string): Promise<JobReminder[]> {
  return load().jobReminders.filter((r) => r.jobId === jobId)
    .sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt));
}

export async function addJobReminderRecord(reminder: JobReminder): Promise<void> {
  const db = load();
  db.jobReminders.push(reminder);
  save(db);
}

export async function deleteJobReminderRecord(id: string): Promise<void> {
  const db = load();
  db.jobReminders = db.jobReminders.filter((r) => r.id !== id);
  save(db);
}

export async function deleteAllJobRemindersForJob(jobId: string): Promise<void> {
  const db = load();
  db.jobReminders = db.jobReminders.filter((r) => r.jobId !== jobId);
  save(db);
}

// ─── Scratch Notes ─────────────────────────────────────────────────────────────

export async function getAllScratchNotes(): Promise<ScratchNote[]> {
  return (load().scratchNotes || []).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function createScratchNote(note: ScratchNote): Promise<void> {
  const db = load();
  db.scratchNotes = [note, ...(db.scratchNotes || [])];
  save(db);
}

export async function updateScratchNote(note: ScratchNote): Promise<void> {
  const db = load();
  db.scratchNotes = (db.scratchNotes || []).map((n) => (n.id === note.id ? note : n));
  save(db);
}

export async function deleteScratchNote(id: string): Promise<void> {
  const db = load();
  db.scratchNotes = (db.scratchNotes || []).filter((n) => n.id !== id);
  save(db);
}

// ─── Job Image Gallery Operations ─────────────────────────────────────────────

export async function getJobImages(jobId: string): Promise<JobImage[]> {
  const db = load();
  return (db.jobImages || [])
    .filter((i) => i.jobId === jobId)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

export async function addJobImage(image: JobImage): Promise<void> {
  const db = load();
  db.jobImages = [image, ...(db.jobImages || [])];
  save(db);
}

export async function deleteJobImage(id: string): Promise<void> {
  const db = load();
  db.jobImages = (db.jobImages || []).filter((i) => i.id !== id);
  save(db);
}

// ─── Studio Concept Operations ────────────────────────────────────────────────

export async function getStudioConceptsByJob(jobId: string): Promise<StudioConcept[]> {
  const db = load();
  return (db.studioConcepts || [])
    .filter((c) => c.jobId === jobId)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

export async function getStudioConceptsByCustomer(customerId: string): Promise<StudioConcept[]> {
  const db = load();
  return (db.studioConcepts || [])
    .filter((c) => c.customerId === customerId)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
}

export async function getStudioConceptById(id: string): Promise<StudioConcept | null> {
  const db = load();
  return (db.studioConcepts || []).find((c) => c.id === id) ?? null;
}

export async function createStudioConcept(concept: StudioConcept): Promise<void> {
  const db = load();
  db.studioConcepts = [concept, ...(db.studioConcepts || [])];
  save(db);
}
